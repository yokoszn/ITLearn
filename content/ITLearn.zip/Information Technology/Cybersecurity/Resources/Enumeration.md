[[Nmap]]
[[SQLMap]]
[[Gobuster]]
