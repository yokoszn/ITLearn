___
**Tags:** [[Cyber Security]][[tools]][[Phishing]] [[man-in-the-middle attack]]

**Links:** 

---

# Evilginx 3.0

[](https://github.com/kgretzky/evilginx2#evilginx-30)

**Evilginx** is a man-in-the-middle attack framework used for phishing login credentials along with session cookies, which in turn allows to bypass 2-factor authentication protection.

This tool is a successor to [Evilginx](https://github.com/kgretzky/evilginx), released in 2017, which used a custom version of nginx HTTP server to provide man-in-the-middle functionality to act as a proxy between a browser and phished website. Present version is fully written in GO as a standalone application, which implements its own HTTP and DNS server, making it extremely easy to set up and use.