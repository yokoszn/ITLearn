#programming
- #bash
- #powershell
- #algorithms
- #object-oriented-programming
- #functional-programming
- #services
- #system-monitoring
- #logging 

![[Quoting in Bash]]
