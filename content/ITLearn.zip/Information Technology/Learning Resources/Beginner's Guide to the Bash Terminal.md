---
{}
---
#video #Learning
#practice-exercises #certification-prep #linux 

___
**Tags:** 

**Links:**  [Beginner's Guide to the Bash Terminal - YouTube](https://www.youtube.com/watch?v=oxuRxtrO2Ag)

---

[[Linux Commands for Beginners - Full Course]]
[[Linux Networking Commands for System Administrators]]
[[Command Line Arguments for Beginners - Full Course]]