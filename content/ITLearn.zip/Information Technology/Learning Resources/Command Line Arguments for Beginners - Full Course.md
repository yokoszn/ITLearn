---
{}
---

___
**Tags:**  #video #Learning
#practice-exercises #certification-prep 

**Links:**  [Command Line Arguments for Beginners - Full Course - YouTube](https://www.youtube.com/watch?v=PMfC0Q9RObM)

---
[[Bash]]
[[Syntax Logic]]

 [[securing an ubuntu server]]
 [[Command Line Arguments for Beginners - Full Course]]
[[Linux Commands for Beginners - Full Course]]
[[Beginner's Guide to the Bash Terminal]]